package textvars

var (
	WelcomeEmail = "Welcome to our CMS, {{email}}!  We're glad you could join us."
)
