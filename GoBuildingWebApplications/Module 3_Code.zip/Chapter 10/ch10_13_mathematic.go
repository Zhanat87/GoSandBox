package mathematics

func Square(int x) {
	
	return x * 3
}