package main

import
(
	"os"
)

func main() {
	panic("Oh No, we forgot to write a program!")
	os.Exit(1)
}