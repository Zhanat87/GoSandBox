package main

import 
(
	
	"log"
)
func main() {
	
	log.Print("Sending it all to console!")

}